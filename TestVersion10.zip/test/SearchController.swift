//  Class "SearchTableViewController"
//  controls the TableView "Search" in the "Storyboards"
//  Created by Nathan Lewis on 3/2/20

import Foundation
import UIKit

//Contains Song Information parsed from JSON in parseData()
struct post {
    let mainImage : UIImage!
    let name : String!
    let artist : String!
    let uri : String!
}

//Used for search page in storyboards
class SearchTableViewController: UITableViewController, UISearchBarDelegate {

    //Outlet implemented for search bar
    @IBOutlet weak var searchBar: UISearchBar!
    
    //Song information as post struct array
    var posts = [post]()
    
    //standard for the json data
    typealias JSONStandard = [String : AnyObject]
    
    //Show cancel button when text box is selected
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    
    //Hides cancel button when it is pressed
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
    }
    
    //Close keyboard when cancel button is selected
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
    }
    
    //Start query to Spotify API when "Search" is pressed
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        //Text taken from search bar
        let keywords = searchBar.text
        
        //Replaces occurences of certain characters for the sake of the url being correct
        var finalKeywords = keywords?.replacingOccurrences(of: " ", with: "+")
        finalKeywords = finalKeywords?.replacingOccurrences(of: "’", with: "%27")
        
        //Appending user search to the search url and passing it to "callHTTPRequest"
        let searchURL = "https://api.spotify.com/v1/search?q=\(finalKeywords!)&type=track%2Cartist%2Calbum&market=US&limit=20"
        callHTTPRequest(url: searchURL)
        
        //Close the keyboard
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //HTTP Request to Spotify
    func callHTTPRequest(url : String){

        //Guard against an empty url
        guard let requestURL = URL(string: url) else {fatalError()}
        
        //Create url request as GET method
        var request = URLRequest(url: requestURL)
        request.httpMethod = "GET"
        
        //Set OAuth token header for request
        request.setValue("Bearer BQBYOR3chfrULo6Vdkyz4os89BNPra8aWoUgZKetB6x0oSodGZkbHeLz-fFXgXLRA0LYCM-fIM8hntRUjcnuGssz7ZP6Gad9FEKxW83C0yz7LwDfI8IwpJ93_Zcycdw8ezZ9ZtIVrf4bkib1bNzZ", forHTTPHeaderField: "Authorization")
        
        //Create URL Session and return data, response code, and any errors
        let task = URLSession.shared.dataTask(with: request) {(data, response, error) in
            if let error = error {
                print("Error took place \(error)")
                return
            }
            
            if let response = response as? HTTPURLResponse {
                print("Response HTTP Status code: \(response.statusCode)")
            }
            
            //During session, data is passed to parseData to extract information from JSON
            self.parseData(JSONData: data!)
            
        }
        task.resume()   //Necessary to do the task
    }

    //Used to parse data from Spotify for display
    //The JSON returned from Spotify has many layers (sections within sections)
    //Every time there is an "if let" we are going a little deeper every time
    func parseData(JSONData: Data) {
        
        do {
            //Serializing the JSON to make it readable and, therefore, parsable
            let readableJSON = try JSONSerialization.jsonObject(with: JSONData, options: .mutableContainers) as! JSONStandard
            
            //Within "tracks" section of JSON...
            if let tracks = readableJSON["tracks"] as? JSONStandard{
                
                //And within "tracks" section...
                if let items = tracks["items"] as? [JSONStandard] {
                    
                    //When a search is done, remove all of the last search from the Table View
                    posts.removeAll()
                    
                    //For every search result, iterate through and assign values
                    for i in 0..<items.count{
                        let item = items[i]
                        
                        //Assigning value of name to the name value in JSON response from Spotify
                        let name = item["name"] as! String
                        
                        //Assigning value of the uri to the uri given in JSON response from Spotify
                        let uri = item["uri"] as! String
                        
                        //Within "album" section of JSON...
                        if let album = item["album"] as? JSONStandard{
                            
                            //And within "images" section of JSON
                            if let images = album["images"] as? [JSONStandard] {
                                let imageData = images[0]
                                let mainImageURL = URL(string: imageData["url"] as! String)
                                let mainImageData = NSData(contentsOf: mainImageURL!)!
                                let mainImage = UIImage(data: mainImageData as Data)!
                                
                                //Within "artists" section of JSON
                                if let artists = album["artists"] as? [JSONStandard] {
                                    let artistData = artists[0]
                                    let artist = NSString(string: artistData["name"] as! String)
                                    
                                    //Append all information into the array for display
                                    posts.append(post.init(mainImage: mainImage, name: name, artist: artist as String, uri: uri))
                                }
                                
                                //Updating the table view to show search results
                                DispatchQueue.main.async {
                                    self.tableView.reloadData()
                                }
                            } //End "images"
                        } //End "album"
                    } //End for loop
                } //End "items"
            }  //End "tracks"
        } //End do
        
        //catch errors
        catch{
            print(error)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    //Function used to assign values to the table view for display in each cell of the table
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //Identifyer for the table view cells is "Cell"
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        
        let mainImageView = cell?.viewWithTag(2) as! UIImageView
        mainImageView.image = posts[indexPath.row].mainImage
        
        let mainLabel = cell?.viewWithTag(1) as! UILabel
        mainLabel.text = posts[indexPath.row].name
        
        let secondLabel = cell?.viewWithTag(3) as! UILabel
        secondLabel.text = "By: " + posts[indexPath.row].artist
        
        return cell!
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = self.tableView.indexPathForSelectedRow?.row
        
        let vc = segue.destination as! HomeViewController
        
        vc.song = posts[indexPath!].name
        vc.artist = posts[indexPath!].artist
        
    }
}
