//
//  eternalJukeboxLoginViewController.swift
//  test
//
//  Created by Lane Kealey on 3/2/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit

class eternalJukeboxLoginViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        firstTimeLoginSwitch.transform = CGAffineTransform(scaleX: 0.75, y: 0.75)
        //firstTimeLoginButton.layer.cornerRadius = 15
        //firstTimeLoginSwitch.backgroundColor = UIColor .white
        //firstTimeLoginSwitch.layer.cornerRadius = firstTimeLoginSwitch.frame.height / 2/0.75
        //firstTimeLoginSwitch.tintColor = UIColor .white
        firstTimeLoginSwitch.layer.borderWidth = firstTimeLoginSwitch.frame.width / 12.35
        
        

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var firstTimeLoginSwitch: UISwitch!
    
    
    @IBOutlet weak var firstTimeLoginButton: UIButton!

    
    @IBOutlet weak var verificationNumberField: UITextField!
    @IBAction func firstTimeLoginToggle(_ sender: Any) {
        if firstTimeLoginSwitch.isOn == false {
            verificationNumberField.isHidden=true
            
        }
        else{
            verificationNumberField.isHidden=false
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
