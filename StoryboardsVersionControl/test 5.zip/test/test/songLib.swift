//
//  songLib.swift
//  test
//
//  Created by Lane Kealey on 2/15/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import Foundation
struct Song{
    var songName: String
    var songArtist:String
    var genre:String
    init(songName:String, songArtist:String, genre:String){
        self.songName = songName
        self.songArtist = songArtist
        self.genre = genre
    }
}
