//
//  SearchController.swift
//  test
//
//  Created by Nathan Lewis on 3/2/20

import Foundation
import UIKit

//Contains Song Information parsed from JSON in parseData()
struct post {
    let mainImage : UIImage!
    let name : String!
}

//Used for search page in storyboards
class SearchTableViewController: UITableViewController, UISearchBarDelegate {

    //Outlet implemented for search bar
    @IBOutlet weak var searchBar: UISearchBar!
    
    //Song information as post struct array
    var posts = [post]()
    
    //standard for the json data
    typealias JSONStandard = [String : AnyObject]
    
    //Cancel button implementation
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
    }
    
    //Start query to Spotify API when "Search" is pressed
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        let keywords = searchBar.text
        var finalKeywords = keywords?.replacingOccurrences(of: " ", with: "+")
        print(finalKeywords!)
        finalKeywords = finalKeywords?.replacingOccurrences(of: "’", with: "%27")
        print(finalKeywords!)
        
        let searchURL = "https://api.spotify.com/v1/search?q=\(finalKeywords!)&type=track%2Cartist%2Calbum&market=US&limit=20"
        callHTTPRequest(url: searchURL)
        
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //HTTP Request to Spotify
    func callHTTPRequest(url : String){

        guard let requestURL = URL(string: url) else {fatalError()}
        
        var request = URLRequest(url: requestURL)
        request.httpMethod = "GET"
        
        request.setValue("Bearer BQAR_--m4wPMP0_PB4xXlWUSJ2dZiRucV9H-ZOQ1kqANOH_VVhjI5k2IgXGCGVSPZIh0L-Lhq6rEMqS2sFTBb4cRhiH6jC_5E69jMW_2VoC1PS9htJurMeMzbapbgVRYxB0tIggoNludf9MFZe7Z", forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request) {(data, response, error) in
            if let error = error {
                print("Error took place \(error)")
                return
            }
            
            if let response = response as? HTTPURLResponse {
                print("Response HTTP Status code: \(response.statusCode)")
            }
            
            self.parseData(JSONData: data!)
            
        }
        task.resume()
    }

    //used to parse data from spotify for display
    func parseData(JSONData: Data) {
        
        do {
            let readableJSON = try JSONSerialization.jsonObject(with: JSONData, options: .mutableContainers) as! JSONStandard
            if let tracks = readableJSON["tracks"] as? JSONStandard{
                if let items = tracks["items"] as? [JSONStandard] {
                    posts.removeAll()
                    for i in 0..<items.count{
                        let item = items[i]
                        let name = item["name"] as! String
                        
                        if let album = item["album"] as? JSONStandard{
                            if let images = album["images"] as? [JSONStandard] {
                                let imageData = images[0]
                                let mainImageURL = URL(string: imageData["url"] as! String)
                                let mainImageData = NSData(contentsOf: mainImageURL!)!
                                
                                let mainImage = UIImage(data: mainImageData as Data)!
                                
                                posts.append(post.init(mainImage: mainImage, name: name))
                                
                                DispatchQueue.main.async {
                                    self.tableView.reloadData()
                                }
                            }
                        }
                    }
                }
            }
        }
        catch{
            print(error)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        
        let mainImageView = cell?.viewWithTag(2) as! UIImageView
        
        mainImageView.image = posts[indexPath.row].mainImage
        
        let mainLabel = cell?.viewWithTag(1) as! UILabel
        
        mainLabel.text = posts[indexPath.row].name
        
        return cell!
    }
}
