//
//  SettingsViewController.swift
//  test
//
//  Created by Lane Kealey on 3/2/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var branchSimilarity: UISlider!
    
    
    @IBOutlet weak var branchProbMax: UISlider!
    
    @IBOutlet weak var probIncrease: UISlider!
    
    @IBOutlet weak var minJumpDistance: UISlider!
    
    @IBOutlet weak var loopExtensionOptimization: UISwitch!
    
    @IBOutlet weak var onlyReverseBranches: UISwitch!
    
    @IBOutlet weak var onlyLongbranches: UISwitch!
    
    @IBOutlet weak var removeSequentialBranches: UISwitch!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
