//
//  ViewControllerSearchViewController.swift
//  test
//
//  Created by Lane Kealey on 2/17/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit

class ViewControllerSearchViewController: UIViewController, UISearchBarDelegate {

    @IBOutlet weak var searchBar: UISearchBar!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.showsCancelButton = true
        searchBar.delegate = self
        // Do any additional setup after loading the view.
    }
    

    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
    }
    
    func searchBarCancelButtonClick (_ searchBar: UISearchBar)
    {
        searchBar.text = ""
        searchBar.showsCancelButton = false
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
