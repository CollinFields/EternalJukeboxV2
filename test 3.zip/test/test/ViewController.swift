//
//  ViewController.swift
//  test
//
//  Created by Lane Kealey on 1/29/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBSegueAction func ShowSearch(_ coder: NSCoder) -> UIViewController? {
        return <#UIViewController(coder: coder)#>
    }
    
}

