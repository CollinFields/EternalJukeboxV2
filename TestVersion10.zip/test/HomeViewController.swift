//
//  HomeScreenViewController.swift
//  test
//
//  Created by Lane Kealey on 3/2/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit
import Foundation

class HomeViewController: UIViewController {

    var song = String()
    var artist = String()
    
    @IBOutlet weak var songName: UILabel!
    
    @IBOutlet weak var artistName: UILabel!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        songName.text = song
        artistName.text = artist

    }
}
