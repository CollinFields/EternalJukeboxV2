//
//  SettingsViewController.swift
//  test
//
//  Created by Lane Kealey on 3/2/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func changeBrancheSimilarity(_ sender: UISlider) {
        let branchSimilarityValue = Int(sender.value)
        
        
        branchSimilarityLabel.text = String(branchSimilarityValue)
        
        
        
    }
    
    @IBAction func changeProbMax(_ sender: UISlider) {
        let probMax = Int(sender.value)
        
        
        probMaxLabel.text = String(probMax)
        
    }
    
    @IBAction func changeProbIncrease(_ sender: UISlider) {
        let probIncrease = Int(sender.value)
        
        
        probIncreaseLabel.text = String(probIncrease)
    }
    
   
    @IBAction func changeMinJump(_ sender: UISlider) {
        let minJump = Int(sender.value)
        
        
        minJumpDistanceLabel.text = String(minJump)
    }
    @IBOutlet weak var branchSimilarity: UISlider!
    
    
    @IBOutlet weak var branchProbMax: UISlider!
    
    @IBOutlet weak var probIncrease: UISlider!
    
    @IBOutlet weak var minJumpDistance: UISlider!
    
    @IBOutlet weak var loopExtensionOptimization: UISwitch!
    
    @IBOutlet weak var onlyReverseBranches: UISwitch!
    
    @IBOutlet weak var onlyLongbranches: UISwitch!
    
    @IBOutlet weak var removeSequentialBranches: UISwitch!
    
    @IBOutlet weak var branchSimilarityLabel: UILabel!
    
    @IBOutlet weak var probMaxLabel: UILabel!
    
    @IBOutlet weak var probIncreaseLabel: UILabel!
    
    @IBOutlet weak var minJumpDistanceLabel: UILabel!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
