//
//  ViewController.swift
//  test
//
//  Created by Lane Kealey on 1/29/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
          self.performSegue(withIdentifier: "loginScreenSegue", sender: self)
        }
        
        
    }
    
   
}

