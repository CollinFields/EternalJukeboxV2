//
//  forgotPasswordPinViewController.swift
//  test
//
//  Created by Lane Kealey on 3/2/20.
//  Copyright © 2020 Lane Kealey. All rights reserved.
//

import UIKit

class forgotPasswordPinViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let tap: UIGestureRecognizer=UITapGestureRecognizer(target: self,action: "dismissKeyboard")
                     view.addGestureRecognizer(tap)

              // Do any additional setup after loading the view.

        // Do any additional setup after loading the view.
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
